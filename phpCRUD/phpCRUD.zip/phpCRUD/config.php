<?php 
 $servername = "localhost";
    $username = "root";
    $password = "";
$db= 'university';
$link = mysqli_connect($servername, $username, $password , $db);
?>