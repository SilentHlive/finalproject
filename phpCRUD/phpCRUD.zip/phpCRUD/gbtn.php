<?php
$output= '<a href="#" id="btn" class="w3-button">Generate</a>';
echo $output;
?>