<?php
   $output = '<h2 align="center">PHP CRUD GENERATOR</h2>';
   echo $output;
?>