<?php
   $output = '<title>PHP CRUD GENERATOR</title>';
   echo $output;
?>